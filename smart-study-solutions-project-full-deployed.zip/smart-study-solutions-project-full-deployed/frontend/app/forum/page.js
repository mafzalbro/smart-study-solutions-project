// ForumPage.js

"use client";

import ForumPage from "../components/forum/ForumPage";


const page = () => {

  return (
    <section className="p-8">
        <ForumPage />
    </section>
  );
};

export default page;
