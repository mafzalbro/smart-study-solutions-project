import React from 'react'
import LoginForm from '../components/LoginForm'
const page = () => {
    return (
    <>
        <LoginForm />
    </>
  )
}

export default page