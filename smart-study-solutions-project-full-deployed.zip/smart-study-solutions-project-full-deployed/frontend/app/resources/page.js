import ResourcesList from '@/app/components/ResourceList'
import React from 'react'
const page = () => {
    return (
        <>
        <ResourcesList />
    </>
  )
}

export default page