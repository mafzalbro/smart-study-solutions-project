import React from 'react'

const Hr = () => {
  return (
    <hr className='w-[20vw] my-12 bg-orange-500 border-none h-0.5'/>
  )
}

export default Hr