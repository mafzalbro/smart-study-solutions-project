import React from 'react'
import ContactUs from '../components/ContactUs'
import Link from 'next/link'
const ContactPage = () => {
    return (
        <>
    
    <ContactUs />
    </>
  )
}

export default ContactPage