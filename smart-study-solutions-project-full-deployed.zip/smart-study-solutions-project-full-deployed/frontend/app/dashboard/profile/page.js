import UserDetails from '@/app/components/dashboard/userDetails'
import React from 'react'

const page = () => {
  return (
    <>
      <UserDetails />
    </>
  )
}

export default page