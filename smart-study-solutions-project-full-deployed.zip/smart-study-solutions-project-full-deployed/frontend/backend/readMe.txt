i have to change 

admin auth
auth -> role student - teacher
Notifications not working
AI Logs Implementation
allow to create admin or add new admin
go with signup or login with google


--

Explain DOCs (go with everyting pdfs, presentations, spreadsheets)

getimages instead if pdf is not text based

-- extract data
-- if not data there
-- send all images and get summary of each and return summary
-- store
-- it all runs behind the scenes

--------------------

change password option
add sort, search and filter for all not endpoint but as a param
stream the pdf answer
keep the context
change mongodb chatHistory
change filter, sort, search, pagination

---------------------

change topics based chatHistory (done)

---------------------

Please make backend amazing
work on long documents and image pdfs
clear chat as sooner as possible
then go to next one faster
